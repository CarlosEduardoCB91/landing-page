import submitForm from './submitForm';

export default submitForm