import { Dialog } from "./Dialog";

export default Dialog;