import { FieldText } from "./FieldText";

export default FieldText;
