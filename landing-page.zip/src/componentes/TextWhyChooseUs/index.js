import { TextWhyChooseUs } from "./TextWhyChooseUs";

export default TextWhyChooseUs;